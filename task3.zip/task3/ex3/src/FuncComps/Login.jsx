import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useState } from 'react';
import { useNavigate } from 'react-router';


export default function Login({
    //Gets the option to change the logged in user
    setCurrentUser,setAdminIsLogIn
}) {
    const[loginUsername,setloginUsername]=useState('');
    const[loginPassword,setloginPassword]=useState('');
    var UsersArr=JSON.parse(localStorage.getItem('Users'));
    const nav = useNavigate()
    
    //We will check if the admin has connected, validation and check if the user exists in the user array
    function loginUser(){
        if(loginUsername=="admin" && loginPassword=="ad12343211ad"){
            setAdminIsLogIn(true);
            nav("/systemAdmin");
            return;
        }
        else{
            setAdminIsLogIn(false);
        }
        if(!validateLogIn()){
            return;
        }
        var found = undefined;
        for(var user of UsersArr) {
            if (user.username==loginUsername && user.password==loginPassword){ 
                    found = user;
                    console.log(found);
                    break;
            }
            
        }

        if(found) {
            sessionStorage.setItem('LoginUser',JSON.stringify(found));
            setCurrentUser(user)
            nav("/") 
        } else {
            alert('User name or password incorrect');
        }

    }

    function validateLogIn() {
        const usernameRegex = /^[a-zA-Z0-9!@#$%^&*]{1,60}/;
        if (!loginUsername.match(usernameRegex)  || loginUsername.length>61||loginUsername.length<1) {
            alert('Invalid user name. Please check your details.');
            document.getElementById("usernamelogin").value="";
            setloginUsername(null);
            return false;
        }
        const passwordRegex = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,12}/;
        if (!loginPassword.match(passwordRegex) || loginPassword.length<7||loginPassword.length>12) {
            alert('Invalid password. Please check your details.');
            document.getElementById("passwordlogin").value="";
            setloginPassword(null);
            return false;
        }
        return true;
    }

    return(
    <div><br/><br/><br/><br/>
        <form>
            <h2>Log In</h2>
                <TextField id="usernamelogin" label="User Name" variant="standard" onChange={(e)=>setloginUsername(e.target.value)}/><br/><br/>
                <TextField id="passwordlogin" label="Password" type='password' variant="standard" onChange={(e)=>setloginPassword(e.target.value)}/><br/><br/>
                <Button type='submit' variant="outlined" onClick={loginUser}>Log In</Button>
        </form>     
    </div>
)}
