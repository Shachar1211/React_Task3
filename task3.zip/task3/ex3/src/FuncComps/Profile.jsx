import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import EmailIcon from '@mui/icons-material/Email';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import PlaceIcon from '@mui/icons-material/Place';
import CakeIcon from '@mui/icons-material/Cake';
import Avatar from '@mui/material/Avatar';
import { useEffect, useState } from 'react';
import { monthsList } from "../utilities/Collections";
import EditDetails from './EditDetails';
import Link from '@mui/material/Link';

export default function Profile({user,setCurrentUser}) { 
  const[showP,setshowP]=useState(false);
  const[showCard,setshowCard]=useState(true);
  const [showEd, setShowEd] = useState(false);

  function checkIfUserInTheSystem(){
    if(JSON.parse(sessionStorage.getItem('LoginUser'))=="null-user"){
      setshowP(true);
      setshowCard(false);      
    }
  }

  useEffect(() => {
    checkIfUserInTheSystem();
  }, [user.email]);

  function convertDate(){ 
    if(JSON.parse(sessionStorage.getItem('LoginUser'))!="null-user"){
       var udate=user.dateofbirth.split("-");
       var monthIndex=parseInt(udate[1], 10) - 1;
       var currentMonth=monthsList[monthIndex];
       var dateAsString=udate[0]+" "+"ב"+currentMonth+" "+udate[2];
      return dateAsString;
    }
     else dateAsString="";    
  }
  function logoutUser(){
    sessionStorage.setItem('LoginUser',JSON.stringify("null-user"));
    setshowP(true);
    setshowCard(false);
  }
  useEffect(() => {
  }, [showP]);


  const handleEditClick = () => {
    setShowEd(!showEd);
  };
    return(
      <div>
        <div><br/><br/><br/><br/>   
          
          {showP && <p id='needToLogIn'>יש להתחבר למערכת</p>}
          {showCard && <Card id='profileCard' sx={{ minWidth: 275}}>
          <Avatar sx={{height:150, width:150,marginTop:5,marginLeft:3}} alt="profile image" src={user.image} />
          <CardContent> 
          <Typography defaultValue={user.name} sx={{textAlign:'left', marginTop:-18,marginLeft:23,fontSize:20}} variant="h5" component="div" >
          {user.firstname} {user.lastname}
          </Typography>
          <List sx={{marginLeft:23}}>
            <ListItem  disablePadding>
                <ListItemIcon>
                  <EmailIcon sx={{height:17,width:17}}/>
                </ListItemIcon>
                <ListItemText secondary={user.email} />
            </ListItem>
            <ListItem disablePadding>
                <ListItemIcon>
                  <PlaceIcon sx={{height:17,width:17}}/>
                </ListItemIcon>
                <ListItemText secondary={user.street + " " + user.housenum + "," + user.city}  />
            </ListItem>
            <ListItem disablePadding>
                <ListItemIcon>
                  <CakeIcon sx={{height:17,width:17}}/>
                </ListItemIcon>                      
                <ListItemText secondary={convertDate()}/>
            </ListItem>
          </List>
          </CardContent>
          <CardActions>
          <Stack spacing={2} direction="row">
          <Button variant="outlined" sx={{backgroundColor:"#B7B5B2",color:"white",border:"none"}} onClick={handleEditClick}>Update details</Button>
          <Button variant="outlined" sx={{backgroundColor:"	#A9C8CF",color:"white",border:"none"}}><Link sx={{underline:"none",color:"inherit"}} href='https://www.solnet.co.il/spider-2suits'>To the game</Link></Button>
          <Button variant="outlined" sx={{backgroundColor:"#EB836B",color:"white",border:"none"}} onClick={logoutUser}>Log out</Button>
          </Stack>
          </CardActions>
          </Card>}
        </div>
        <div>
        {showEd && <EditDetails currentUser={user} setCurrentUser={setCurrentUser} setShowEd={setShowEd}/>}
        </div>
      </div>
    )  
}