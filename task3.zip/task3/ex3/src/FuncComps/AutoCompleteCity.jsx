import { useState } from "react";
import { citiesList } from "../utilities/Collections";


export default function AutoCompleteCity({
    onSelectCity
}) {

    const [cities, setCities] = useState(citiesList);
    const [filteredCities, setFilteredCities] = useState([]);
    const [selected,setSelected] = useState();
    
    return <div>
        <input className="auto-complete" onInput={(e) => setFilteredCities(!e.target.value ? [] :  cities.filter(c => c.includes(e.target.value)))} placeholder="Search city.."/>
        <div className="list">
        {filteredCities.map(city => <div key={city} onClick={() =>{
            onSelectCity(city)
            setFilteredCities([])
            setSelected(city)
        }}>
                    {city}
    </div>)}
    </div>
    {selected &&<div>
        Selected: {selected}
    </div>}

    </div>
}