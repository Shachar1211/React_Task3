import './App.css';
import Register from './FuncComps/Register';
import Login from "./FuncComps/Login";
import Profile from './FuncComps/Profile';
import EditDetails from './FuncComps/EditDetails';
import { useEffect, useState } from 'react';
import { Routes, Route, Link, json} from 'react-router-dom'
import SystemAdmin from './FuncComps/SystemAdmin';


function App() {
  const [AdminIsLogIn,setAdminIsLogIn] = useState(false);
    const [currentUser,setCurrentUser] = useState(
      JSON.parse(sessionStorage.getItem('LoginUser')) ?? "null-user"
    )
  
  
  const [UsersArr,setUsersArr] = useState(
    JSON.parse(localStorage.getItem('Users'))
  )
  useEffect(()=>{},[currentUser,UsersArr])

  const Menu = () => {
    console.log('currentUser',currentUser);
    if(currentUser=="null-user"||AdminIsLogIn ) {  //If no user is logged in he can only access these pages
        return  <nav>
            <Link to="/">Home</Link>
            <Link to="/register">Register</Link>
            <Link to="/login">Login</Link>
        </nav>
    }
    return <nav>
      <Link to="/">Home</Link>
      <Link to="/register">Register</Link>
      <Link to="/login">Login</Link>
      <Link to="/profile">Profile</Link>
    </nav>  
  }
  return (
    <>
      <div>
      <Menu/>
        <Routes>
          <Route index element={<div>Howdy!</div>}/>
          <Route path="/register" element={ <Register/> }/>
          <Route path="/login" element={ <Login setCurrentUser={setCurrentUser} setAdminIsLogIn={setAdminIsLogIn}/> }/>
          <Route path="/profile" element={ <Profile user ={currentUser} setCurrentUser={setCurrentUser}/> }/>
          <Route path="/edit-profile" element={  <EditDetails currentUser={currentUser}  setCurrentUser={setCurrentUser} /> }/>
          <Route path="/systemAdmin" element={ <SystemAdmin usersArr={UsersArr} currentUser={currentUser} setCurrentUser={setCurrentUser} /> }/>
       </Routes>
      </div>
    </>
  )
}

export default App
